package com.bookshopping.model;

public enum GenderType {
    male,
    female,
    other
}
