package com.bookshopping.model;

public enum AuthProvider {
    local,
    facebook,
    google,
    github
}
