package com.bookshopping.service;

import com.bookshopping.model.Category;

import java.util.List;

public interface CategoryService {
    List<Category> findAll();
}
