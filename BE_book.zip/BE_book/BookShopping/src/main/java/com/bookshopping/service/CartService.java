package com.bookshopping.service;

import com.bookshopping.model.Cart;

public interface CartService {
    Cart save(Cart cart);
}
